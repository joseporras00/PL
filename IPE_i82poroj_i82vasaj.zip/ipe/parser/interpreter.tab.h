/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2019 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_INTERPRETER_TAB_H_INCLUDED
# define YY_YY_INTERPRETER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    PUNTOCOMA = 258,
    LEER = 259,
    LEER_CAD = 260,
    ESCRIBIR = 261,
    ESCRIBIR_CAD = 262,
    SI = 263,
    ENTONCES = 264,
    SI_NO = 265,
    FIN_SI = 266,
    MIENTRAS = 267,
    HACER = 268,
    FIN_MIENTRAS = 269,
    REPETIR = 270,
    HASTA = 271,
    PARA = 272,
    FIN_PARA = 273,
    PASO = 274,
    DESDE = 275,
    CASOS = 276,
    VALOR = 277,
    DEFECTO = 278,
    FIN_CASOS = 279,
    CADENA = 280,
    COMENTARIO_UNA = 281,
    COMENTARIO_VARIAS = 282,
    ASSIGNMENT = 283,
    COMA = 284,
    DOSPUNTOS = 285,
    NUMBER = 286,
    BOOL = 287,
    VARIABLE = 288,
    UNDEFINED = 289,
    CONSTANT = 290,
    BUILTIN = 291,
    OR = 292,
    AND = 293,
    PLUS = 294,
    MINUS = 295,
    MULTIPLICATION = 296,
    DIVISION = 297,
    MODULO = 298,
    DIVENTERA = 299,
    NOT = 300,
    LPAREN = 301,
    RPAREN = 302,
    GREATER_OR_EQUAL = 303,
    LESS_OR_EQUAL = 304,
    GREATER_THAN = 305,
    LESS_THAN = 306,
    EQUAL = 307,
    NOT_EQUAL = 308,
    CONCAT = 309,
    UNARY = 310,
    POWER = 311
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 50 "interpreter.y" /* yacc.c:1921  */

  char * identifier;
  char * cadena;
  double number;  
  bool logic;					
  lp::ExpNode *expNode;  			
  std::list<lp::SwitchValueNode *>  *parameters;  
  std::list<lp::Statement *> *stmts; 
  lp::Statement *st;	
  lp::AST *prog;

#line 127 "interpreter.tab.h" /* yacc.c:1921  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_INTERPRETER_TAB_H_INCLUDED  */
